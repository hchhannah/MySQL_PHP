-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- 主機： 127.0.0.1
-- 產生時間： 2022-06-16 09:31:03
-- 伺服器版本： 10.4.24-MariaDB
-- PHP 版本： 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 資料庫： `hila`
--

-- --------------------------------------------------------

--
-- 資料表結構 `catalog`
--

CREATE TABLE `catalog` (
  `id` int(100) NOT NULL,
  `category` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 傾印資料表的資料 `catalog`
--

INSERT INTO `catalog` (`id`, `category`) VALUES
(0, '資料收集紀錄器'),
(1, '指針電錶'),
(2, '數字電錶'),
(3, '各式鉤錶'),
(4, 'LCR錶、電容錶'),
(5, '直流電源供應器'),
(6, '數字溫度計'),
(7, '信號產生器'),
(8, '溫濕度計、水分計'),
(9, '電磁波測量儀'),
(10, '膜厚計'),
(11, '高阻、微阻、接地電阻計'),
(12, '紅外線溫度計、熱像儀'),
(13, '汽車錶'),
(14, '檢相計、照度計'),
(15, '風速計、轉速計'),
(16, '酸鹼計、鹽分計'),
(17, '壓力計、差壓計'),
(18, 'USB感測記錄器'),
(19, '交流穩壓器'),
(20, '各式錶頭'),
(21, '各式測試棒、夾'),
(22, '各式氣體偵測器');

-- --------------------------------------------------------

--
-- 資料表結構 `member`
--

CREATE TABLE `member` (
  `id` int(100) NOT NULL,
  `name` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 傾印資料表的資料 `member`
--

INSERT INTO `member` (`id`, `name`, `password`, `email`) VALUES
(1, 'amy', '12345', 'amy@gmail.com'),
(2, 'joy', '54321', 'joy@gmail.com'),
(3, 'haha', '99999', 'haha@gmail.com'),
(4, 'jaja', '123456789', 'jaja@gmail.com'),
(5, 'pp', '456789', 'pp@gmail.com'),
(6, 'aaa', 'bbb', 'aaa@gmail.com'),
(7, 'manager', 'manager', 'manager@gmail.com'),
(9, 'hehe', 'hehehe', 'hehe@gmail.com'),
(10, 'bbb', 'ccc', 'bbb@gmail.com'),
(11, 'ccc', 'ddd', 'ccc@gmail.com'),
(12, 'ddd', 'aaa', 'ddd@gmail.com'),
(14, 'nana', 'hehe', 'nana@gmail.com');

-- --------------------------------------------------------

--
-- 資料表結構 `product`
--

CREATE TABLE `product` (
  `model` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_name` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reference` int(100) NOT NULL,
  `price` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 傾印資料表的資料 `product`
--

INSERT INTO `product` (`model`, `product_name`, `reference`, `price`, `id`) VALUES
('BLE-TP01', 'Android藍牙溫度資料收集記錄器', 0, '2000', 1),
('BLE-RH05', 'Android藍牙溫濕度資料收集記錄器', 0, '1200', 2),
('Win-TP01', 'Windows USB溫度感測記錄器', 0, '3500', 3),
('Win-RH05', 'Windows USB溫濕度感測記錄器', 0, '3500', 4),
('HA-360', '實用型指針三用電錶', 1, '1000', 5),
('HA-370', '指針式三用電錶', 1, '500', 6),
('HA-380', '指針式三用電錶', 1, '750', 7),
('DM-3200', '多功能數字電錶', 2, '1200', 8),
('DM-3500', '多功能自動換檔電錶', 2, '1500', 9),
('DM–5200', '智慧型數字電錶', 2, '2000', 10),
('DM-6200', '多功能自動換檔電錶', 2, '3000', 11),
('DM-825', '數字三用電錶', 2, '300', 12),
('HA-9000A', '多功能數字交流鉤錶', 3, '500', 13),
('CIE-2608C', '數字大電流交直流鉤錶', 3, '500', 14),
('FM-200', '數位式叉型交直流鉤錶', 3, '500', 15),
('CHY-903', '多功能數字交流鉤錶', 3, '750', 16),
('CHY-9006', 'AC600A TRMS功率鉤錶', 3, '750', 17),
('CHY-15', '數字專業電容錶', 4, '900', 18),
('LCR-58', 'SMD數位式LCR夾錶', 4, '900', 19),
('CHY-24CS', '專業LCR電錶', 4, '1200', 20),
('DM-2630', '3,½ 數字LCR電錶True Rms', 4, '1200', 21),
('CHY-21', '多功能LCR數字電錶', 4, '1500', 22),
('DP-3003N', '數字直流電源供應器30V/3A', 5, '1500', 23),
('DP-3020', '數字直流電源供應器30V/20A', 5, '1500', 24),
('DPS-系列', '大功率直流電源供應器', 5, '3000', 25),
('TM-905A', 'K-Type數字溫度計', 6, '750', 26),
('TM-906A', '雙組K-Type數字溫度計', 6, '750', 27),
('CHY-200', 'K型數位熱電耦溫度計', 6, '750', 28),
('CIE-307P', '雙組K-Type數字溫度計', 6, '800', 29),
('CHY-806A', '多功能記錄溫度計', 6, '500', 30),
('HFG-205D', '5MHz DDS 雙輸出信號產生器', 7, '500', 31),
('TFG-3510E', '10MHz DDS 雙輸出信號產生器', 7, '900', 32),
('TFG-3600E系列', 'DDS 數位任意波信號產生器', 7, '1200', 33),
('TE-608', '多功能高精度溫濕度記錄器', 8, '1500', 34),
('CHY-220', '數位式溫濕度計', 8, '500', 35),
('HA-5040', '數字溫濕度計', 8, '500', 36),
('CHY-322', '數位式溫度/濕度/濕球/露點量測計', 8, '500', 39),
('ED-15SA', 'CORNET高頻電磁波測量儀+2.4GHz頻譜', 9, '850', 40),
('MD-18', 'CORNET高頻電磁波測量儀', 9, '800', 41),
('ED-78SPlus', '美商CORNET高頻+低頻電磁波測量儀', 9, '850', 42),
('TG-03', '導磁型膜厚計', 10, '850', 43),
('TG-05', '導磁/非導磁兩用型膜厚計', 10, '1200', 44),
('CHY-113', '槍型導磁膜厚計', 10, '1000', 45),
('CHY-115', '槍型導磁/非導磁膜厚計', 10, '1200', 46),
('ZGkb201P', '多功能室內空氣品質監測儀', 11, '5000', 47),
('HA-120', '瓦斯偵測器', 11, '3000', 48),
('TE-718', '手持式甲醛測試儀', 11, '1200', 49),
('CHY-370', '一氧化碳偵測計', 11, '3000', 50),
('DPM-741XV', '數字電壓錶頭', 12, '500', 51),
('DPM-740XA系列', '數字電流錶頭', 12, '500', 52),
('CIE-8088A', '多功能汽車錶(噴射引擎)', 13, '2000', 53),
('CHY-230', '數位式照度計', 14, '500', 54),
('CHY-331', '數位式照度計', 14, '500', 55),
('CHY-731', '高精度照度計', 14, '1200', 56),
('CHY-260', '風速-溫度計', 15, '350', 57),
('CHY-360', '風速-溫度計', 15, '350', 58),
('CHY-361', '風速-溫度計', 15, '350', 59),
('CHY-250', '光電式轉速計', 15, '500', 60),
('DT-2238A', 'DT-2238A數位式轉速計', 15, '750', 61),
('CHY-392R', '數位酸鹼計', 16, '500', 62),
('CHY-391', '鹽分計', 16, '500', 63),
('CHY-280', '差壓計', 17, '500', 64),
('CHY-886U', '雙輸入差壓計', 17, '750', 65),
('CHY-281', '絕對壓力計', 17, '550', 66),
('CHY-885U', '空調用之過熱、過冷壓力計', 17, '550', 67),
('BLE-TP01', 'Android藍牙溫度資料收集記錄器', 18, '3500', 68),
('BLE-RH05', 'Android藍牙溫濕度資料收集記錄器', 18, '3500', 69),
('Win-TP01', 'Windows USB溫度感測記錄器', 18, '3500', 70),
('Win-RH05', 'Windows USB溫濕度感測記錄器', 18, '3500', 71),
('AVR伺服馬達式', '伺服馬達式-交流穩壓器', 19, '1500', 72),
('FC-C02', '安規香蕉I-香蕉L連接線', 20, '150', 73),
('FC-A32', '大鱷魚夾+鋼針(母4mm)', 20, '150', 74),
('FC-A40', '小鱷魚夾(母2mm)', 20, '100', 75),
('FC-N02', '伸縮探針(母2mm轉接)', 20, '250', 76),
('FC-N07', '1mm不鏽鋼探針(母2mm)', 20, '250', 77),
('FC-N14', '57mm微鉤夾(母2mm)', 20, '150', 78),
('M-1000', '指針式絕緣高阻計', 21, '500', 79),
('M-280A', 'M-280A數字三段式絕緣高阻計', 21, '550', 80),
('M-580C', '數字微電阻計', 21, '550', 81),
('TIM-03V', '紅外線熱像儀', 22, '3000', 82),
('TN-49SCG', '550℃防潑水紅外線溫度計', 22, '1200', 83),
('TN-568LC2', '2400℃紅外線溫度計', 22, '3000', 84),
('TN-433L', '365℃紅外線溫度計', 22, '3500', 85),
('CHY-210', '550℃紅外線溫度計', 22, '5000', 86);

-- --------------------------------------------------------

--
-- 資料表結構 `repair_q`
--

CREATE TABLE `repair_q` (
  `id` int(225) NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `repair_q` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- 資料表結構 `shopping_cart`
--

CREATE TABLE `shopping_cart` (
  `id` int(225) NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 傾印資料表的資料 `shopping_cart`
--

INSERT INTO `shopping_cart` (`id`, `email`, `model`, `product_name`, `price`) VALUES
(15, 'jaja@gmail.com', 'ED-78SPlus', '美商CORNET高頻+低頻電磁波測量儀', '1500'),
(16, 'jaja@gmail.com', 'ED-78SPlus', '美商CORNET高頻+低頻電磁波測量儀', '1500'),
(17, 'jaja@gmail.com', 'Win-RH05', 'Windows USB溫濕度感測記錄器', '3500'),
(18, 'jaja@gmail.com', 'Win-RH05', 'Windows USB溫濕度感測記錄器', '3500'),
(19, 'jaja@gmail.com', 'ED-78SPlus', '美商CORNET高頻+低頻電磁波測量儀', '1500'),
(20, 'jaja@gmail.com', 'Win-RH05', 'Windows USB溫濕度感測記錄器', '3500'),
(21, 'jaja@gmail.com', 'CHY-322', '數位式溫度/濕度/濕球/露點量測計', '500'),
(30, 'haha@gmail.com', 'FC-C02', '安規香蕉I-香蕉L連接線', '150'),
(31, 'haha@gmail.com', 'FC-A32', '大鱷魚夾+鋼針(母4mm)', '150'),
(32, 'haha@gmail.com', 'ED-15SA', 'CORNET高頻電磁波測量儀+2.4GHz頻譜', '850'),
(33, 'haha@gmail.com', 'HA-9000A', '多功能數字交流鉤錶', '350'),
(37, 'amy@gmail.com', 'HFG-205D', '5MHz DDS 雙輸出信號產生器', '500'),
(38, 'amy@gmail.com', 'TFG-3510E', '10MHz DDS 雙輸出信號產生器', '900'),
(39, 'amy@gmail.com', 'ED-15SA', 'CORNET高頻電磁波測量儀+2.4GHz頻譜', '850');

--
-- 已傾印資料表的索引
--

--
-- 資料表索引 `catalog`
--
ALTER TABLE `catalog`
  ADD PRIMARY KEY (`id`);

--
-- 資料表索引 `member`
--
ALTER TABLE `member`
  ADD PRIMARY KEY (`id`);

--
-- 資料表索引 `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- 資料表索引 `repair_q`
--
ALTER TABLE `repair_q`
  ADD PRIMARY KEY (`id`);

--
-- 資料表索引 `shopping_cart`
--
ALTER TABLE `shopping_cart`
  ADD PRIMARY KEY (`id`);

--
-- 在傾印的資料表使用自動遞增(AUTO_INCREMENT)
--

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `catalog`
--
ALTER TABLE `catalog`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `member`
--
ALTER TABLE `member`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `product`
--
ALTER TABLE `product`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=87;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `repair_q`
--
ALTER TABLE `repair_q`
  MODIFY `id` int(225) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `shopping_cart`
--
ALTER TABLE `shopping_cart`
  MODIFY `id` int(225) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
