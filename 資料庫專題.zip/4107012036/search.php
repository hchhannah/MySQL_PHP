
 <?php
	session_start(); //啟用交談期
	
	$mail = "";
	
	//取得表單欄位值
	if (isset($_POST["mail"]))
		$mail = $_POST["mail"];
	
	// <!-- //建立MySQL的資料庫連接 -->
	$link = mysqli_connect("localhost","root","FU6C06mic","hila")
			or die("無法開啟MySQL資料庫連接！<br/>");

	
	// // <!-- //指定SQL字串 -->
	$sql_show = "SELECT password FROM `member` WHERE email = '{$mail}'";

	
	$result = mysqli_query($link, $sql_show);
	$total_records = mysqli_num_rows($result);
	
	if ($total_records > 0){
		while($row = mysqli_fetch_array($result)){
			$output [] = $row;
		}
		$_SESSION["search_pw"] = $output[0]['password'];		
		// echo $total_records;
		header("Location: search_success.php#download");
		
	}else{
		header("Location: search_fail.php#download");
	}
	

?>
