
 <?php
	session_start(); //啟用交談期
	
	$value = "";
	
	//取得表單欄位值
	if (isset($_POST["value"]))
		$value = $_POST["value"];
	
	// <!-- //建立MySQL的資料庫連接 -->
	$link = mysqli_connect("localhost","root","FU6C06mic","hila")
			or die("無法開啟MySQL資料庫連接！<br/>");

	
	// // <!-- //指定SQL字串 -->
	$sql_show = "SELECT `model`, `product_name`, `price` FROM `product` WHERE model = '{$value}' or product_name = '{$value}'";

	
	$result = mysqli_query($link, $sql_show);
	$total_records = mysqli_num_rows($result);
	
	if ($total_records > 0){
		while($row = mysqli_fetch_array($result)){
			$output [] = $row;
		}
		$_SESSION["price_search"] = $output[0]['price'];		
		$_SESSION["model_search"] = $output[0]['model'];		
		$_SESSION["name_search"] = $output[0]['product_name'];		
		// echo $output[0]['price'];
		// print(json_encode($output, JSON_UNESCAPED_UNICODE));
		header("Location: price_success.php#price");
		
	}else{
		header("Location: price_fail.php#price");
	}
	

?>
