<html>
<head>
    <meta charset="utf-8">
	<title>Hila website</title>
</head>
<body>
<?php
		session_start(); //啟用交談期

		$repair_q = "";
		$mail = $_SESSION["email"];
		
		//取得表單欄位值
		if (isset($_POST["repair_q"]))
			$repair_q = $_POST["repair_q"];
		
		// <!-- //建立MySQL的資料庫連接 -->
		$link = mysqli_connect("localhost","root","FU6C06mic","hila")
				or die("無法開啟MySQL資料庫連接！<br/>");
	
		$sql_insert = "INSERT INTO `repair_q`(`email`, `repair_q`) VALUES ('{$mail}','{$repair_q}')";
		mysqli_query($link, $sql_insert);
		
		header("Location: repair_success.php #repair");
	
		//關閉資料庫連接
		mysqli_close($link);

?>
</body>
</html>
		
		