<html>
<head>
    <meta charset="utf-8">
	<title>Hila website</title>
</head>
<body>
<?php
		session_start(); //啟用交談期
				
		$mail = $_SESSION['email'];
		
		$value = "";
		
		//取得表單欄位值
		if (isset($_POST["value"]))
			$value = $_POST["value"];
		
		// <!-- //建立MySQL的資料庫連接 -->
		$link = mysqli_connect("localhost","root","FU6C06mic","hila")
				or die("無法開啟MySQL資料庫連接！<br/>");
		
		$sql = "SELECT  *  FROM shopping_cart WHERE  id = '{$value}' AND email = '{$mail}'";
		$result = mysqli_query($link,$sql);
		$total_records = mysqli_num_rows($result);
		
		if($total_records == 0){	
			$_SESSION['delete_fail']=true;			
			header("Location: index_shopping.php #price");
		} else{
			$sql_delete = "DELETE FROM `shopping_cart` WHERE id = '{$value}' AND email = '{$mail}'";
			mysqli_query($link,$sql_delete);
			$_SESSION['delete_success']=true;
			header("Location: index_shopping.php #price");
		};


		

		// <!-- //關閉資料庫連接 -->
		mysqli_close($link);

?>
</body>
</html>