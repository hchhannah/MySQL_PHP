<?php
		session_start(); //啟用交談期
		
		$mail = "";
		$password = "";
		
		//取得表單欄位值
		if (isset($_POST["mail"]))
			$mail = $_POST["mail"];
		if (isset($_POST["password"]))
			$password = $_POST["password"];
		
		
		//檢查是否輸入使用者名稱和密碼
		if ($mail != "" && $password != ""){
			$link = mysqli_connect("localhost","root","FU6C06mic","hila")
					or die("無法開啟MySQL資料庫連接！<br/>");

			mysqli_query($link,'SET NAMES utf8');
			
			
			echo $password;
			
			$sql_check = "SELECT * FROM member WHERE password = '{$password}'";
			$result = mysqli_query($link,$sql_check);
			$total_records = mysqli_num_rows($result);
			
			if ($total_records > 0){
				// echo $total_records;
				header("Location: changepw_fail.php#download");
			}else{
				//指定SQL字串
				// echo $total_records;
				$sql = "UPDATE `member` SET `password`='{$password}' WHERE email='{$mail}'";
				mysqli_query($link, $sql);
				header("Location: changepw_success.php");
				
			}
			
			mysqli_close($link);
		}

	?>