<html>
<head>
    <meta charset="utf-8">
	<title>Hila website</title>
</head>
<body>
<?php
		session_start(); //啟用交談期
		
		$mail = $_SESSION['email'];
	
		//建立MySQL的資料庫連接
		$link = mysqli_connect("localhost","root","FU6C06mic","hila")
				or die("無法開啟MySQL資料庫連接！<br/>");
	
		$sql_delete = "DELETE FROM `repair_q`";
		$result = mysqli_query($link,$sql_delete);
		$_SESSION['mdeleteall_success']=true;
		header("Location: index_manager_repair.php #price");

		

		// <!-- //關閉資料庫連接 -->
		mysqli_close($link);

?>
</body>
</html>