<html>
<head>
    <meta charset="utf-8">

</head>
<body>

<?php
		session_start(); //啟用交談期
		$mail = $_SESSION['email'];
		$model = $_SESSION['model'.$_GET['name']];
		$product_name = $_SESSION['product_name'.$_GET['name']];
		$price = $_SESSION['price'.$_GET['name']];
		$id=$_SESSION['id'];
	
		
		// <!-- //建立MySQL的資料庫連接 -->
		$link = mysqli_connect("localhost","root","FU6C06mic","hila")
				or die("無法開啟MySQL資料庫連接！<br/>");
				
		
		if ( $_SESSION['login']!= true ){
			header("Location: index.php #download");
		} else{
			 $sql_insert = "INSERT INTO `shopping_cart`(`id`, `email`, `model`, `product_name`, `price`) VALUES (NULL, '{$mail}', '{$model}','{$product_name}','{$price}')";
			 $result = mysqli_query($link,$sql_insert);
			 $_SESSION['insert_success']=true;
			header("Location: link.php?id=$id");
		};
		
		

		// <!-- //關閉資料庫連接 -->
		mysqli_close($link);

?>
</body>
</html>
		
		