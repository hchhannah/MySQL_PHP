<html>
<head>
    <meta charset="utf-8">
	<title>Hila website</title>
</head>
<body>
<?php
	session_start(); //啟用交談期
	
	$name = "";
	$password = "";
	$mail = "";
	
	//取得表單欄位值
	if (isset($_POST["name"]))
		$name = $_POST["name"];
	if (isset($_POST["password"]))
		$password = $_POST["password"];
	
	
	//檢查是否輸入使用者名稱和密碼
	if ($name != "" && $password != ""){
		$link = mysqli_connect("localhost","root","FU6C06mic","hila")
				or die("無法開啟MySQL資料庫連接！<br/>");

		mysqli_query($link,'SET NAMES utf8');

		$sql = "SELECT * FROM member WHERE password = '{$password}' AND name = '{$name}'";

		// echo $name;
		// echo $password;

		//執行SQL查詢
		$result = mysqli_query($link,$sql);
		$total_records = mysqli_num_rows($result);
	

		//是否有查詢到使用者紀錄
		if ($total_records > 0){
			if ($name == "manager" AND $password =="manager"){
				header("Location: index_manager.php");				
			}else{
				//成功登入
				$_SESSION["login_session"] = true;
				$sql_search = "SELECT email FROM `member` WHERE password = '{$password}'";
				$result = mysqli_query($link,$sql_search);
				while($row = mysqli_fetch_array($result)){
					$output [] = $row;
				}
				$_SESSION["email"] = $output[0]['email'];
				// echo $_SESSION["email"];
				$_SESSION["login_name"] = $name;
				
				header("Location: login_success.php");
			}
		} else{
			//登入失敗
			$_SESSION["login_session"] = false;
			header("Location: login_fail.php#download");
		}
		mysqli_close($link);
	}

?>
</body>
</html>
		
		