<html>
<head>
    <meta charset="utf-8">
	<title>Hila website</title>
</head>
<body>
<?php
		session_start(); //啟用交談期

		$name = "";
		$password = "";
		$mail = "";

		//取得表單欄位值
		if (isset($_POST["name"]))
			$name = $_POST["name"];
		if (isset($_POST["password"]))
			$password = $_POST["password"];
		if (isset($_POST["mail"]))
			$mail = $_POST["mail"];
			
		// 建立MySQL的資料庫連接 
		$link = mysqli_connect("localhost","root","FU6C06mic","hila")
				or die("無法開啟MySQL資料庫連接！<br/>");
		
		$sql = "SELECT * FROM member WHERE password = '{$password}' OR email = '{$mail}'";
		$result = mysqli_query($link,$sql);
		$total_records = mysqli_num_rows($result);
		
		if ($total_records > 0){
			header("Location: signup_fail.php#download");
		}else{
			$sql_insert = "INSERT INTO `member` (`id`,`name`,`password`,`email`) VALUES (NULL, '{$name}', '{$password}','{$mail}')";
			mysqli_query($link, $sql_insert);
			$_SESSION["email"] = $mail;
			header("Location: signup_success.php#download");
		}
		
		// <!-- //關閉資料庫連接 -->
		mysqli_close($link);

?>
</body>
</html>
		
		