<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang=""> <!--<![endif]-->
<head>
	<meta charset="utf-8">
    <!--<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">-->
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <title>Hila website</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="apple-touch-icon" href="apple-touch-icon.png">
    <link rel="icon" type="image/png" href="favicon-32x32.png" sizes="32x32" />
    <link rel="icon" type="image/png" href="favicon-16x16.png" sizes="16x16" />
    <link rel="stylesheet" href="css/normalize.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/jquery.fancybox.css">
    <link rel="stylesheet" href="css/flexslider.css">
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="css/queries.css">
    <link rel="stylesheet" href="css/etline-font.css">
    <link rel="stylesheet" href="bower_components/animate.css/animate.min.css">
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
    <script src="js/vendor/modernizr-2.8.3-respond-1.4.2.min.js"></script>
	<!--Import Google Icon Font-->
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

	
	<!-- Compiled and minified JavaScript -->
	<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
	<!-- 利用Google Visualization讀取Google Sheet https://www.labnol.org/code/google-sheet-d3js-visualization-200608 -->
	<script src="https://www.gstatic.com/charts/loader.js"></script>

	<!-- <!--讀試算表準備--> 
	<!-- <script> -->
		<!-- // https://developers.google.com/chart/interactive/docs/quick_start -->
		<!-- // Load the Visualization API and the corechart package. -->
		<!-- google.charts.load('current', { 'packages': ['corechart'] }); -->

		<!-- // Set a callback to run when the Google Visualization API is loaded.	 -->
		<!-- google.charts.setOnLoadCallback(init); -->

		<!-- function init() { -->
			<!-- var url = 'https://docs.google.com/spreadsheets/d/1No8clCpZnyUI1FXafrYPNKHPghXzbsXWlVGJORWTFNE/gviz/tq?sheet=工作表1'; -->
			<!-- var query = new google.visualization.Query(url); -->
			<!-- query.setQuery('select *'); -->
			<!-- query.send(processSheetsData); -->
		<!-- } -->
	<!-- </script> -->

	

</head>

<body>
	
	<?php
		session_start(); //啟用交談期
	
		// <!-- //建立MySQL的資料庫連接 -->
		$link = mysqli_connect("localhost","root","FU6C06mic","hila")
				or die("無法開啟MySQL資料庫連接！<br/>");
	
		// // <!-- //指定SQL字串 -->
	
		// $sql_show = "SELECT `model`, `product_name` ,`price` FROM `product` WHERE reference = '{$_GET['id']}'";
		// $_SESSION['id'] = $_GET['id'];
		// $result = mysqli_query($link, $sql_show);
		// $total_records = mysqli_num_rows($result);
		// $_SESSION["link"] = true;
		// // echo $total_records;
		// while($row = mysqli_fetch_array($result)){
			// $output [] = $row;
		// }
		// // print(json_encode($output, JSON_UNESCAPED_UNICODE));
		
		mysqli_close($link);
	?>
	<script>
		// 要先取得網址裡的參數
		var X = decodeURIComponent(GetUrlVar('id'));
		var i = Number(X);
		
		if (<?php $_SESSION["link"] == false; ?>){
			location="manager_link.php?id=" + i;
		};
		
	</script>
	<!-- <!--網站標題 & 開頭 --> 
	<section class="hero">
        <section class="navigation">
            <header>
                <div class="header-content">
                    <div class="logo"><a href="#top"><img src="img/LOGO.png" height = "30" ></a></div>
                    <div class="header-nav">
                        <nav>
							<!--最上面-->
							
                             <ul class="primary-nav">
								<li><a href="index_manager.php #top">首頁</a></li>
                                <li><a href="index_manager.php#menu">目錄</a></li>
                                <li><a href="index_manager.php#menu"><u>修改產品內容</u></a></li>
                            </ul>
                            
                            <ul class="member-actions">
                               <li><a href="#top" class="login">Hi&nbsp;!&nbsp;&nbsp;歡迎&nbsp;Manager&nbsp;!&nbsp;&nbsp;</a></li>
								<li><a href="index.php" class="btn-white btn-small">Log out</a></li>
                            </ul>
                        </nav>
                    </div>
                    <div class="navicon">
                        <a class="nav-toggle" href="#"><span></span></a>
                    </div>
                </div>
            </header>
    </section>
	<!-- 上面中間介紹  -->
        <div class="container">
            <div class="row">
                <div class="col-md-10 col-md-offset-1">
                    <div class="hero-content ">    
							
						
								<img src="products/<?php echo $_SESSION['cmodel'];?>_工作區域 1.jpg" align="right" height="275px">     
								<h4><font color="white">產品型號：<?php echo $_SESSION['cmodel'];?>
								</font></h4>
								<h4><font color="white">產品名稱：<?php echo $_SESSION['cname'] ;?>
								</font></h4>
								<br>
								<h4><font color="white">產品價格：<?php echo $_SESSION['cprice'] ;?>
								</font></h4>
								<br><br><br>
								<form class="signup-form" action="manager_change.php" method="POST" role="form">
									<label for "value" class="form-input-group" >
										<input type="text" style="padding:10px;" name="value" id="value" placeholder="Enter new price here" required>
									</label>	
									<br>
									<br>
									<button type="submit" class="btn btn-fill btn-large btn-margin-right">修改</button>													
								</form>
								<p class="intro">
								</p>
								
									
										
						
							
                    </div>
                </div>
            </div>
        </div>
        <div class="down-arrow floating-arrow"><a href="#"><i class="fa fa-angle-down"></i></a></div>
    </section>
	
	

	<!-- 底部  -->
	<footer>
        <div class="container">
            <div class="row">
                <div class="col-md-7">
                    <div class="footer-links">
                        <ul class="footer-group">
                            <li><a href="#menu">目錄</a></li>
							<li><a href="#features">最新產品</a></li>
							<li><a href="#download">詢價</a></li>
							<li><a href="#repair">維修</a></li>
							<li><a href="#blog">關於我們</a></li>
                        </ul>
                        <p>Copyright © 海碁國際企業股份有限公司 
						<a href="http://www.manufacture.com.tw/"target="_blank">Taiwan Products,</a>
						<a href="http://www.manufacturers.com.tw/"target="_blank">B2BManufactures,</a>
						<a href="http://www.b2bchinasources.com/"target="_blank">B2BChinaSources</a><br>
                        
                    </div>
                </div>
                <div class="social-share">
                    <p>Share Hila with your friends</p>
                    <a href="https://twitter.com/?lang=zh-tw" target="_blank" class="twitter-share"><i class="fa fa-twitter"></i></a> 
					<a href="https://www.facebook.com/" target="_blank" class="facebook-share"><i class="fa fa-facebook"></i></a>
					
                </div>
            </div>
        </div>
    </footer>

	<!-- JavaScript at end of body for optimized loading  -->
	<script type="text/javascript" src="js/materialize.min.js"></script>
	
</body>

<</html>
<!--document.getElementById("shopping").innerHTML-->