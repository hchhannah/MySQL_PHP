<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang=""> <!--<![endif]-->
<head>
    <meta charset="utf-8">
    <!--<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">-->
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <title>Hila website</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="apple-touch-icon" href="apple-touch-icon.png">
    <link rel="icon" type="image/png" href="favicon-32x32.png" sizes="32x32" />
    <link rel="icon" type="image/png" href="favicon-16x16.png" sizes="16x16" />
    <link rel="stylesheet" href="css/normalize.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/jquery.fancybox.css">
    <link rel="stylesheet" href="css/flexslider.css">
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="css/queries.css">
    <link rel="stylesheet" href="css/etline-font.css">
    <link rel="stylesheet" href="bower_components/animate.css/animate.min.css">
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
    <script src="js/vendor/modernizr-2.8.3-respond-1.4.2.min.js"></script>

</head>
<body id="top">
	 <?php
		session_start(); //啟用交談期
	
		// <!-- //建立MySQL的資料庫連接 -->
		$link = mysqli_connect("localhost","root","FU6C06mic","hila")
				or die("無法開啟MySQL資料庫連接！<br/>");
	
		// // <!-- //指定SQL字串 -->
		$sql_show = "SELECT * FROM `catalog`";
		$result = mysqli_query($link, $sql_show);
		while($row = mysqli_fetch_array($result)){
			$output [] = $row;
		}
		$_SESSION["link"] = false;
	 ?>
		
    <!--[if lt IE 8]>
    <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
    <![endif]-->
    <section class="hero">
        <section class="navigation">
            <header>
                <div class="header-content">
                    <div class="logo"><a href="#top"><img src="img/LOGO.png" height = "30" ></a></div>
                    <div class="header-nav">
                        <nav>
							<!--最上面-->
							<?php
							if ($_SESSION['login']==true){?>
							
                            <ul class="primary-nav">
								<li><a href="login_success.php">首頁</a></li>
                                <li><a href="#menu">目錄</a></li>
                                <li><a href="#features">最新產品</a></li>
                                <li><a href="#price">詢價</a></li>
								<li><a href="#repair">維修</a></li>
                                <li><a href="#blog">關於我們</a></li>
                                <li><a href="index_changepw.php#download"><u>更改密碼</u></a></li>
								
                            </ul>
                            
                            <ul class="member-actions">
                                <li><a href="#top" class="login">Hi&nbsp!&nbsp&nbsp歡迎&nbsp<?php echo $_SESSION["login_name"];?>&nbsp&nbsp!&nbsp</a></li>
								<li><a href="index.php" class="btn-white btn-small">Log out</a></li>
                            </ul>
							<?php 
							}else{?>
								<ul class="primary-nav">
                                <li><a href="index.php">首頁</a></li>
                                <li><a href="#menu">目錄</a></li>
                                <li><a href="#features">最新產品</a></li>
                                <li><a href="#price">詢價</a></li>
								<li><a href="#repair">維修</a></li>
                                <li><a href="#blog">關於我們</a></li>
                            </ul>
                            <ul class="member-actions">
                                <li><a href="#download" class="login">Log in</a></li>
                                <li><a href="index_signup.php#download" class="btn-white btn-small">Sign up</a></li>
                            </ul>
							<?php
								};
								?>
							
                        </nav>
                    </div>
                    <div class="navicon">
                        <a class="nav-toggle" href="#"><span></span></a>
                    </div>
                </div>
            </header>
        </section>
		<!--上面中間介紹-->
        <div class="container">
            <div class="row">
                <div class="col-md-10 col-md-offset-1">
                    <div class="hero-content text-center">
                        <h1>專業創新，用心服務</h1>
                        <p class="intro">電子、電機、電工、環保測量儀器儀表</p>
                        <a href="#" class="btn btn-fill btn-large btn-margin-right">購物車</a> 
						<a href="http://www.hila.com.tw/exec/product.php?lg=T" target="_blank" class="btn btn-accent btn-large">Learn more</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="down-arrow floating-arrow"><a href="#features"><i class="fa fa-angle-down"></i></a></div>
    </section>
			
	<!--第二個白色的part-->
    <section class="intro section-padding" id = "menu">
        <div class="container">
            <div class="row">
			
                <div class="intro-feature">
                    <div class="intro-icon">
					<!--icon-->
                        <span data-icon="&#xe030;" class="icon"></span>
                    </div>
					<!--旁邊的介紹-->
						<table>
							<tr>
								<td><font size="4"><?php
								for ($i = 0; $i < 6; $i++) {
									print"<a href ='link.php?id={$i}'><b>";
									echo $output[$i]['category'];
									print"</b>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;";
									
									echo "<br>";
								}
								?></a></font></td>
								<br>
								<td><font size="4"><?php
								for ($i = 6; $i < 12; $i++) {
									print"<a href ='link.php?id={$i}'><b>";
									echo $output[$i]['category'];
									print"</b>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;";
									
									echo "<br>";
								}
								?></a></font></td>
								<td><font size="4"><?php
								for ($i = 12; $i < 18; $i++) {
									print"<a href ='link.php?id={$i}'><b>";
									echo $output[$i]['category'];
									print"</b>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;";
									
									echo "<br>";
								}
								?></a></font></td>
								<td><font size="4"><?php
								for ($i = 18; $i < 23; $i++) {
									print"<a href ='link.php?id={$i}'><b>";
									echo $output[$i]['category'];
									print"</b>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;";
									
									echo "<br>";
								}
								?><br></a></font></td>
							</tr>
						</table>				
                </div>
            </div>
        </div>
    </section>
	<!--第三個part-->
    <section class="features section-padding" id="features">
        <div class="container">
            <div class="row">
                <div class="col-md-5 col-md-offset-7">
                    <div class="feature-list">
                        <h3>Android藍牙溫度資料收集記錄器</h3>
                        <p>適用於冷藏運輸業、養殖業、農林畜牧業、倉儲、醫療用品、冰箱、食品等監控記錄</p>
                        <ul class="features-stack">
                            <li class="feature-item">
                                <div class="feature-icon">
                                    <span data-icon="&#xe03e;" class="icon"></span>
                                </div>
                                <div class="feature-content">
                                    <h5>NCC型式認證，臺灣生產製造</h5>
                                    <p>Android 5.0安卓5.0以上手機及平板適用</p>
                                </div>
                            </li>
                            <li class="feature-item">
                                <div class="feature-icon">
                                    <span data-icon="&#xe040;" class="icon"></span>
                                </div>
                                <div class="feature-content">
                                    <h5>無線藍牙連接傳輸</h5>
                                    <p>可用行動裝置監控、不須保持連線，可獨立作業<br/></p>
                                </div>
                            </li>
                            <li class="feature-item">
                                <div class="feature-icon">
                                    <span data-icon="&#xe03c;" class="icon"></span>
                                </div>
                                <div class="feature-content">
                                    <h5>產品尺寸</h5>
                                    <p>71(W)x71(H)x24(D)mm<br>測棒：24(W)x172(H)x21(D)mm</br></p>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="device-showcase">
		<!--第三個part的照片-->
            <div class="devices">
				<div class = "wrap wp1">
					<img src="img/BLE-RH05_01-1.png" height="900" style="position:relative;down:1000px;left:290px;">
				</div>
                <!--<div class="ipad-wrap wp1"></div>
                <div class="iphone-wrap wp2"></div>-->
            </div>
        </div>
        <div class="responsive-feature-img"><img src="img/BLE-RH05_01-1.png" alt="responsive devices"></div>
    </section>
	<!--第四個part-->
    <section class="features-extra section-padding" id="assets">
        <div class="container">
            <div class="row">
                <div class="col-md-5">
                    <div class="feature-list">
						<p><div class="wrap wp3">
							<img src="img/Win-RH05_APP_21.png" style="position:absolute;down:2000px;left:550px;">
						</div></p>
                        <h3>PM2.5、CO2、甲醛、溫濕度偵測紀錄</h3>
                        <p>適用於冷藏運輸業、養殖業、農林畜牧業、倉儲、醫療用品、冰箱、食品等監控記錄</p>
                        <p>用途冷鏈運輸記錄、生產履歷記錄、動態測試記錄</p>
                        <div class="wrap wp2">
							<img src="img/AQI-A3_01.png" height="400"style="position:relative;top:160px;left:150px;">
						</div>
						<p style="position:absolute;top:265px">特色<br>
						■ Data Log資料儲存紀錄2000筆存取<br>
						■ 無線藍牙連接傳輸<br>
						■ 高精準度誤差小<br>
						■ 可用行動裝置監控<br>
						■ 不須保持連線,可獨立作業<br>
						■ 可外接DC 5V電源做為長時間監控紀錄<br>
						■ 內建磁鐵,可磁吸於鐵板上<br>
						■ NCC型式認證，臺灣生產製造</br></p>
                        <a href="#" class="btn btn-ghost btn-accent btn-small"style="position:absolute;top:550px">LEARN MORE</a>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="responsive-feature-img"><img src="img/macbook-pro.png" alt="responsive devices"></div>
    </section>
	<!--第五個part-->
    <section class="hero-strip section-padding" id="repair">
        <div class="container">
            <div class="col-md-12 text-center">
                <h2>
                專人服務維修
                </h2>
                <p>價格合理，視情況免維修費！</p>
                <a href="index_repair.php #download" class="btn btn-ghost btn-accent btn-large">我要報修</a>
                <div class="logo-placeholder floating-logo"><img src="img/sketch-logo.png" alt="Sketch Logo"></div>
            </div>
        </div>
    </section>
	<!--第六個part-->
    <section class="blog-intro section-padding" id="blog">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h3>關於 海碁國際股份有限公司</h3>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6 col-sm-12 col-xs-12 leftcol">
                    <h5>聯絡方式</h5>
                    <p>TEL : +886-2-23820929<br>FAX : +886-2-23316722<br>E-mail : service@hila.com.tw</p>
					<img src="img/LOGO2.png" width="200">
                </div>
				<!--地圖-->
                <div class="col-md-6 col-sm-12 col-xs-12 rightcol">
                    <h5>地圖</h5>
					<div id="map">
						<iframe width = "350" height = "200" src="https://maps.google.com.tw/maps?f=q&hl=zh-TW&geocode=&q=25.0478962315014, 121.508234499758&output=embed"></iframe>
					</div>
                    <p>10841 台北市萬華區忠孝西路2段16巷10號1樓</p>
                </div>
            </div>
        </div>
    </section>
    <section class="blog text-center">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-4">
                    <article class="blog-post">
                        <figure>
                            <a href="img/img01.png" class="single_image">
                                <div class="blog-img-wrap">
                                    <div class="overlay">
                                        <i class="fa fa-search"></i>
                                    </div>
                                    <img src="img/img01.png" alt="Sedna blog image"/>
                                </div>
                            </a>
                            <figcaption>
                            <h2><a href="http://www.hila.com.tw/exec/download.php?lg=T&cid=5&mid=5" target="_blank" class="blog-category" data-toggle="tooltip" data-placement="top" data-original-title="Contact us to know more">APP</a></h2>
                            <p><a href="http://www.hila.com.tw/exec/download.php?lg=T&cid=5&mid=5" target="_blank" class="blog-post-title">Getting started with Hila<i class="fa fa-angle-right"></i></a></p>
                            </figcaption>
                        </figure>
                    </article>
                </div>
				<!--照片切換-->
                <div class="col-md-4">
                    <article class="blog-post">
                        <figure>
                            <a href="img/img02.png" class="single_image">
                                <div class="blog-img-wrap">
                                    <div class="overlay">
                                        <i class="fa fa-search"></i>
                                    </div>
                                    <img src="img/img02.png" alt="Sedna blog image"/>
                                </div>
                            </a>
                            <figcaption>
                            <h2><a href="http://www.hila.com.tw/exec/download.php?lg=T&cid=5&mid=5" target="_blank" class="blog-category" data-toggle="tooltip" data-placement="top" data-original-title="Contact us to know more">Interface</a></h2>
                            <p><a href="http://www.hila.com.tw/exec/download.php?lg=T&cid=5&mid=5" target="_blank" class="blog-post-title">Connected<i class="fa fa-angle-right"></i></a></p>
                            </figcaption>
                        </figure>
                    </article>
                </div>
                <div class="col-md-4">
                    <article class="blog-post">
                        <figure>
                            <a href="img/img03.png" class="single_image">
                                <div class="blog-img-wrap">
                                    <div class="overlay">
                                        <i class="fa fa-search"></i>
                                    </div>
                                    <img src="img/img03.png" class="single_image" alt="Sedna blog image"/>
                                </div>
                            </a>
                            <figcaption>
                            <h2><a href="http://www.hila.com.tw/exec/download.php?lg=T&cid=5&mid=5" target="_blank" class="blog-category" data-toggle="tooltip" data-placement="top" data-original-title="Contact us to know more">Interface</a></h2>
                            <p><a href="http://www.hila.com.tw/exec/download.php?lg=T&cid=5&mid=5" target="_blank" class="blog-post-title">Detect<i class="fa fa-angle-right"></i></a></p>
                            </figcaption>
                        </figure>
                    </article>
                </div>
                <a href="http://www.hila.com.tw/exec/download.php?lg=T&cid=5&mid=5" target="_blank" class="btn btn-ghost btn-accent btn-small">Download</a>
            </div>
        </div>
    </section>
<!--常見問題-->
    <section class="testimonial-slider section-padding text-center">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="flexslider">
                        <ul class="slides">
                            <li>
                                <div class="avatar"><img src="img/avatar.jpg" alt="Sedna Testimonial Avatar"></div>
                                <h2>"請問這個有保固嗎?"</h2>
                                <p class="author">:有的</p>
                            </li>
                            <li>
                                <div class="avatar"><img src="img/avatar.jpg" alt="Sedna Testimonial Avatar"></div>
                                <h2>"請問這個面板生鏽可以換一個嗎?"</h2>
                                <p class="author">:可以免費更換</p>
                            </li>
                            <li>
                                <div class="avatar"><img src="img/avatar.jpg" alt="Sedna Testimonial Avatar"></div>
                                <h2>"請問這個有附帶配件嗎?"</h2>
                                <p class="author">:有的</p>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>
	<!--詢價-->
    <section class="sign-up section-padding text-center" id="price">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-md-offset-3">
                    <h3>詢價</h3>
                    <p>搜尋結果</p>
                    <table>
						<tr>
							<td><b>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;產品型號：</td>
							<td style="position:relative;right:0px">&emsp;&emsp;&emsp;<b><?php echo $_SESSION["model_search"];?></b></td>
						</tr>
						<br>
						<tr>
							<td><b>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;產品名稱：<br></td>
							<td style="position:relative;right:0px">&emsp;&emsp;&emsp;<b><?php echo $_SESSION["name_search"];?></b></td>
						</tr>
						<br>
						<tr>
							<td><b>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;產品價格：<br></td>
							<td style="position:relative;right:0px"><b>&emsp;&emsp;&emsp;<?php echo $_SESSION["price_search"];?></b></td>
						</tr>
					</table>
					<br> 
					<br> 
					
					<?php
					if ($_SESSION['login']==true){?>
					<form method="get" action="login_success.php #price">
						<button type="submit" class="btn btn-accent btn-large">回上一頁</button>
                    </form>
					
					<?php }else{?>
					
					<form method="get" action="index.php #price">
						<button type="submit" class="btn btn-accent btn-large">回上一頁</button>
                    </form>
					
					<?php };?>
					
					
                </div>
            </div>
        </div>
    </section>
	<?php
     if ($_SESSION['login']==false){?>
	<!--會員登入-->
    <section class="sign-up section-padding text-center" id="download">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-md-offset-3">
                    <h3>會員登入</h3>
                    <p>報修、新增購物車請先登入</p>
                    <form class="signup-form" action="login.php" method="POST" role="form">
						<label for "name" class="form-input-group" >
							<i class="fa fa-envelope"></i><input type="text" name="name" id="name" placeholder="Enter your account" required>
						</label>
						<br/>
						<label for "password" class="form-input-group" >		
							<i class="fa fa-lock"></i><input type="password" name="password" id="password" placeholder="Enter your password" required>
						</label>
						<br/>
						<br>
						<button type="submit" class="btn btn-accent btn-large">登入</button>
						<br>
						<br>
						<a href="forgetpw.php#download" class="hoverable" ><u>忘記密碼?</u></a>             
                    </form>
                </div>
            </div>
        </div>
    </section>
	<?php };?>
    <section class="to-top">
        <div class="container">
            <div class="row">
                <div class="to-top-wrap">
                    <a href="#top" class="top"><i class="fa fa-angle-up"></i></a>
                </div>
            </div>
        </div>
    </section>
    <footer>
        <div class="container">
            <div class="row">
                <div class="col-md-7">
                    <div class="footer-links">
                        <ul class="footer-group">
                            <li><a href="#menu">目錄</a></li>
							<li><a href="#features">最新產品</a></li>
							<li><a href="#download">詢價</a></li>
							<li><a href="#repair">維修</a></li>
							<li><a href="#blog">關於我們</a></li>
                        </ul>
                        <p>Copyright © 海碁國際企業股份有限公司 
						<a href="http://www.manufacture.com.tw/"target="_blank">Taiwan Products,</a>
						<a href="http://www.manufacturers.com.tw/"target="_blank">B2BManufactures,</a>
						<a href="http://www.b2bchinasources.com/"target="_blank">B2BChinaSources</a><br>
                        <!--<a href="http://tympanus.net/codrops/licensing/">Licence</a> | Crafted with <span class="fa fa-heart pulse2"></span> for <a href="https://tympanus.net/codrops/">Codrops</a>.</p>-->
                    </div>
                </div>
                <div class="social-share">
                    <p>Share Hila with your friends</p>
                    <a href="https://twitter.com/?lang=zh-tw" target="_blank" class="twitter-share"><i class="fa fa-twitter"></i></a> 
					<a href="https://www.facebook.com/" target="_blank" class="facebook-share"><i class="fa fa-facebook"></i></a>
					
                </div>
            </div>
        </div>
    </footer>
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="js/vendor/jquery-1.11.2.min.js"><\/script>')</script>
    <script src="bower_components/retina.js/dist/retina.js"></script>
    <script src="js/jquery.fancybox.pack.js"></script>
    <script src="js/vendor/bootstrap.min.js"></script>
    <script src="js/scripts.js"></script>
    <script src="js/jquery.flexslider-min.js"></script>
    <script src="bower_components/classie/classie.js"></script>
    <script src="bower_components/jquery-waypoints/lib/jquery.waypoints.min.js"></script>
    <!-- Google Analytics: change UA-XXXXX-X to be your site's ID. -->
    <script>
    (function(b,o,i,l,e,r){b.GoogleAnalyticsObject=l;b[l]||(b[l]=
    function(){(b[l].q=b[l].q||[]).push(arguments)});b[l].l=+new Date;
    e=o.createElement(i);r=o.getElementsByTagName(i)[0];
    e.src='//www.google-analytics.com/analytics.js';
    r.parentNode.insertBefore(e,r)}(window,document,'script','ga'));
    ga('create','UA-XXXXX-X','auto');ga('send','pageview');
    </script>
</body>
</html>

		
<!-- 新增、刪除、修改、查詢、登入、註冊  -->
<!-- 新增：帳號、密碼、詢問事項 -->
<!-- 刪除：詢問事項 -->
<!-- 修改：密碼(?)、詢問事項 -->
<!-- 查詢：價錢、其他人的詢問事項 -->
<!-- 登入：會員 -->
<!-- 註冊：會員 -->

</html>