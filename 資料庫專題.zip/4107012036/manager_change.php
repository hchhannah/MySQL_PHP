<?php
		session_start(); //啟用交談期
		
		$price = "";
		$model = $_SESSION['cmodel'];
		$id = $_SESSION['id'];
		
		
		//取得表單欄位值
		if (isset($_POST["value"]))
			$price = $_POST["value"];
	
		echo $id;
		
		// <!-- //建立MySQL的資料庫連接 -->
		$link = mysqli_connect("localhost","root","FU6C06mic","hila")
				or die("無法開啟MySQL資料庫連接！<br/>");
		if ( $price != "") {
			$sql_update = "UPDATE `product` SET `price`='{$price}' WHERE model='{$model}'";
			$result = mysqli_query($link,$sql_update);
			$_SESSION['minsert_success']=true;
			header("Location: index_manager_link.php?id=$id");
		};

		// <!-- //關閉資料庫連接 -->
		mysqli_close($link);

	?>