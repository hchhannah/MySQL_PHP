<html>
<head>
    <meta charset="utf-8">
	<title>Hila website</title>
</head>
<body>
<?php
		session_start(); //啟用交談期
		
		$value = "";
		
		//取得表單欄位值
		if (isset($_POST["value"]))
			$value = $_POST["value"];
		
		// <!-- //建立MySQL的資料庫連接 -->
		$link = mysqli_connect("localhost","root","FU6C06mic","hila")
				or die("無法開啟MySQL資料庫連接！<br/>");
		
		$sql = "SELECT  *  FROM repair_q WHERE  email = '{$value}'";
		$result = mysqli_query($link,$sql);
		$total_records = mysqli_num_rows($result);
		
		if($total_records == 0){	
			$_SESSION['mdelete_fail']=true;			
			header("Location: index_manager_repair.php #price");
		} else{
			$sql_delete = "DELETE FROM `repair_q` WHERE email = '{$value}'";
			mysqli_query($link,$sql_delete);
			$_SESSION['mdelete_success']=true;
			header("Location: index_manager_repair.php #price");
		};


		

		// <!-- //關閉資料庫連接 -->
		mysqli_close($link);

?>
</body>
</html>