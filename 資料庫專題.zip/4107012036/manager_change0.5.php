<?php
		session_start(); //啟用交談期

		$_SESSION['cmodel'] = $_SESSION['model'.$_GET['name']];
		$_SESSION['cname'] = $_SESSION['product_name'.$_GET['name']];
		$_SESSION['cprice'] = $_SESSION['price'.$_GET['name']];

		$link = mysqli_connect("localhost","root","FU6C06mic","hila")
				or die("無法開啟MySQL資料庫連接！<br/>");
	
		
		header("Location: index_manager_link2.php");

		
		

		// <!-- //關閉資料庫連接 -->
		mysqli_close($link);

	?>